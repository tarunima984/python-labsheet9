students = [
    {"roll": 1, "name": "Aman", "age": 20, "marks": 85},
    {"roll": 2, "name": "Riya", "age": 21, "marks": 90},
    {"roll": 3, "name": "Rahul", "age": 20, "marks": 75}
]

employees = {
    1: {"name": "Aman", "salary": 25000},
    2: {"name": "Riya", "salary": 30000}
}

books = {
    1: "Python",
    2: "DBMS"
}

products = {
    1: "Laptop",
    2: "Mouse"
}
