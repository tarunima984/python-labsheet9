from common import students

for s in students:
    print(s)
