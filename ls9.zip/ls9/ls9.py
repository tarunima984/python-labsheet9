Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

=============== RESTART: C:/Users/hp/OneDrive/Documents/common.py ==============

================ RESTART: C:/Users/hp/OneDrive/Documents/1.py ===============
{'roll': 1, 'name': 'Aman', 'age': 20, 'marks': 85}
{'roll': 2, 'name': 'Riya', 'age': 21, 'marks': 90}
{'roll': 3, 'name': 'Rahul', 'age': 20, 'marks': 75}

================ RESTART: C:/Users/hp/OneDrive/Documents/2.py ===============
1 Aman 85
2 Riya 90
3 Rahul 75

================ RESTART: C:/Users/hp/OneDrive/Documents/3.py ===============
Enter name: Aman
{'roll': 1, 'name': 'Aman', 'age': 20, 'marks': 85}

================ RESTART: C:/Users/hp/OneDrive/Documents/4.py ===============
Enter roll number: 4
Student not found

================ RESTART: C:/Users/hp/OneDrive/Documents/4.py ===============
Enter roll number: 2
{'roll': 2, 'name': 'Riya', 'age': 21, 'marks': 95}

================ RESTART: C:/Users/hp/OneDrive/Documents/5.py ===============
Enter roll number: 3
{'roll': 1, 'name': 'Aman', 'age': 20, 'marks': 85}
{'roll': 2, 'name': 'Riya', 'age': 21, 'marks': 90}

================ RESTART: C:/Users/hp/OneDrive/Documents/6.py ===============
{1: {'name': 'Aman', 'salary': 25000}, 2: {'name': 'Riya', 'salary': 30000}, 3: {'name': 'Rahul', 'salary': 28000}}
{1: {'name': 'Aman', 'salary': 35000}, 3: {'name': 'Rahul', 'salary': 28000}}

================ RESTART: C:/Users/hp/OneDrive/Documents/7.py ===============
{1: 'Python', 2: 'DBMS', 3: 'Java'}
{1: 'C++', 3: 'Java'}

================ RESTART: C:/Users/hp/OneDrive/Documents/8.py ===============
{1: 'Python', 2: 'DBMS', 3: 'Java'}
{1: 'C++', 3: 'Java'}

================ RESTART: C:\Users\hp\OneDrive\Documents\8.py ===============
{1: 'Laptop', 2: 'Mouse', 3: 'Keyboard'}
{1: 'Computer', 3: 'Keyboard'}

================ RESTART: C:/Users/hp/OneDrive/Documents/9.py ===============
1 Aman 85
2 Riya 90
3 Rahul 75


=============== RESTART: C:/Users/hp/OneDrive/Documents/10.py ===============
Hello Python
File deleted

=============== RESTART: C:/Users/hp/OneDrive/Documents/11.py ===============
Table created

=============== RESTART: C:/Users/hp/OneDrive/Documents/12.py ===============
Record inserted if it did not already exist

=============== RESTART: C:/Users/hp/OneDrive/Documents/13.py ===============
(1, 'Aman', 20, 85)

=============== RESTART: C:/Users/hp/OneDrive/Documents/14.py ===============
Enter roll number: 3
Student not found

=============== RESTART: C:/Users/hp/OneDrive/Documents/15.py ===============
Enter roll number: 2
Enter new marks: 59
Marks updated

=============== RESTART: C:/Users/hp/OneDrive/Documents/16.py ===============
Enter roll number: 1
Enter new marks: 78
Marks updated

=============== RESTART: C:/Users/hp/OneDrive/Documents/16.py ===============
Enter roll number: 1
Record deleted if it existed
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/17.py ===============
Total students: 0
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/18.py ===============
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/19.py ===============
Top student: None
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/20.py ===============

1.Add  2.View  3.Update  4.Delete  5.Exit
Enter choice: 2

1.Add  2.View  3.Update  4.Delete  5.Exit
Enter choice: 1
Roll: 4
Name: guchdu
Age: 67
Marks: 90
Record added

1.Add  2.View  3.Update  4.Delete  5.Exit
Enter choice: 3
Roll: 2
New marks: 89
Record updated

1.Add  2.View  3.Update  4.Delete  5.Exit
Enter choice: 4
Roll: 3
Record deleted

1.Add  2.View  3.Update  4.Delete  5.Exit
Enter choice: 2
(4, 'guchdu', 67, 90)

1.Add  2.View  3.Update  4.Delete  5.Exit
Enter choice: 5
