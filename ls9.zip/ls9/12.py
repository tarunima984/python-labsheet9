import sqlite3

con = sqlite3.connect("ls9.db")

con.execute(
    "INSERT OR IGNORE INTO students VALUES (?, ?, ?, ?)",
    (1, "Aman", 20, 85)
)

con.commit()
con.close()

print("Record inserted if it did not already exist")
