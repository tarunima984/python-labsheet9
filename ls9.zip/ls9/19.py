import sqlite3

con = sqlite3.connect("ls9.db")

row = con.execute(
    "SELECT * FROM students ORDER BY marks DESC LIMIT 1"
).fetchone()

print("Top student:", row)

con.close()
