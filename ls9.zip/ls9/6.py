from common import employees

employees[3] = {"name": "Rahul", "salary": 28000}  # Create

print(employees)  # Read

employees[1]["salary"] = 35000  # Update

del employees[2]  # Delete

print(employees)
