from common import students

for s in students:
    print(s["roll"], s["name"], s["marks"])
