from common import students

roll = int(input("Enter roll number: "))

for s in students:
    if s["roll"] == roll:
        s["marks"] = 95
        print(s)
        break
else:
    print("Student not found")
