import sqlite3

con = sqlite3.connect("ls9.db")

count = con.execute(
    "SELECT COUNT(*) FROM students"
).fetchone()[0]

print("Total students:", count)

con.close()
