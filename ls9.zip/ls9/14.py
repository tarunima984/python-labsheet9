import sqlite3

con = sqlite3.connect("ls9.db")

roll = int(input("Enter roll number: "))

row = con.execute(
    "SELECT * FROM students WHERE roll = ?", (roll,)
).fetchone()

print(row if row else "Student not found")

con.close()
