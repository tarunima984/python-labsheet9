from common import products

products[3] = "Keyboard"  # Create
print(products)           # Read

products[1] = "Computer"  # Update
del products[2]           # Delete

print(products)
