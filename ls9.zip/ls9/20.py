import sqlite3

con = sqlite3.connect("ls9.db")

con.execute("""
CREATE TABLE IF NOT EXISTS students(
roll INTEGER PRIMARY KEY,
name TEXT,
age INTEGER,
marks INTEGER
)
""")

while True:
    print("\n1.Add  2.View  3.Update  4.Delete  5.Exit")
    ch = input("Enter choice: ")

    if ch == "1":
        r = int(input("Roll: "))
        n = input("Name: ")
        a = int(input("Age: "))
        m = int(input("Marks: "))

        try:
            con.execute(
                "INSERT INTO students VALUES (?, ?, ?, ?)",
                (r, n, a, m)
            )
            con.commit()
            print("Record added")
        except sqlite3.IntegrityError:
            print("Roll number already exists")

    elif ch == "2":
        for row in con.execute("SELECT * FROM students"):
            print(row)

    elif ch == "3":
        r = int(input("Roll: "))
        m = int(input("New marks: "))

        con.execute(
            "UPDATE students SET marks = ? WHERE roll = ?", (m, r)
        )
        con.commit()
        print("Record updated")

    elif ch == "4":
        r = int(input("Roll: "))

        con.execute("DELETE FROM students WHERE roll = ?", (r,))
        con.commit()
        print("Record deleted")

    elif ch == "5":
        break

    else:
        print("Invalid choice")

con.close()
