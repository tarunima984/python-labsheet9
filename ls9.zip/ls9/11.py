import sqlite3

con = sqlite3.connect("ls9.db")

con.execute("""
CREATE TABLE IF NOT EXISTS students(
roll INTEGER PRIMARY KEY,
name TEXT,
age INTEGER,
marks INTEGER
)
""")

con.commit()
con.close()

print("Table created")
