from common import students

name = input("Enter name: ")

for s in students:
    if s["name"].lower() == name.lower():
        print(s)
        break
else:
    print("Student not found")
