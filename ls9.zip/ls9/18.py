import sqlite3

con = sqlite3.connect("ls9.db")

for row in con.execute("SELECT * FROM students ORDER BY name"):
    print(row)

con.close()
