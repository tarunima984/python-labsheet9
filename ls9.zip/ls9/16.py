import sqlite3

con = sqlite3.connect("ls9.db")

roll = int(input("Enter roll number: "))

con.execute("DELETE FROM students WHERE roll = ?", (roll,))

con.commit()
con.close()

print("Record deleted if it existed")
