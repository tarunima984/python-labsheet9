import sqlite3

con = sqlite3.connect("ls9.db")

roll = int(input("Enter roll number: "))
marks = int(input("Enter new marks: "))

con.execute(
    "UPDATE students SET marks = ? WHERE roll = ?",
    (marks, roll)
)

con.commit()
con.close()

print("Marks updated")
