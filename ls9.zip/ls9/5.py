from common import students

roll = int(input("Enter roll number: "))

students = [s for s in students if s["roll"] != roll]

for s in students:
    print(s)
