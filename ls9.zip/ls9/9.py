from common import students

with open("students.txt", "w") as f:
    for s in students:
        f.write(f"{s['roll']} {s['name']} {s['marks']}\n")

with open("students.txt", "r") as f:
    print(f.read())
