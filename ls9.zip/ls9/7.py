from common import books

books[3] = "Java"  # Create
print(books)       # Read

books[1] = "C++"   # Update
del books[2]       # Delete

print(books)
